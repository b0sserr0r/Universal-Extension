from __future__ import print_function
from universal_extension import UniversalExtension
from universal_extension import ExtensionResult
from universal_extension import ui
from universal_extension import logger

import time
import shutil
import os
import random
import json


class Extension(UniversalExtension):
    def __init__(self):
        """Initializes an instance of the 'Extension' class"""
        # Call the base class initializer
        super(Extension, self).__init__()
        self.stop = False

    def transfer_file(self, src_path, dst_path):
        # Ensure destination directory exits
        if not os.path.exists(dst_path):
            raise FileNotFoundError(
                "Destination directory ({0}) does not exist".format(dst_path)
            )

        # Ensure the source file is not already present in the destination
        # directory (unless overwrite is selected)
        if os.path.exists(os.path.join(dst_path, os.path.basename(src_path))):
            logger.info(
                "'{0}' already exists in '{1}'".format(
                    os.path.basename(src_path), dst_path
                )
            )
            return False

        shutil.copy(src_path, dst_path)
        time.sleep(random.uniform(0, 2))

        return True

    def extension_start(self, fields):
        """Required method that serves as the starting point for work performed
        for a task instance.

        Parameters
        ----------
        fields : dict
            populated with field values from the associated task instance
            launched in the Controller

        Returns
        -------
        ExtensionResult
            once the work is done, an instance of ExtensionResult must be
            returned. See the documentation for a full list of parameters that
            can be passed to the ExtensionResult class constructor
        """

        files_transferred = []
        src = fields["src_folder"]
        dst = fields["dst_folder"]

        file_types = [
            ft.lower() if ft.startswith(".") else "." + ft.lower()
            for ft in fields["file_type"]
        ]

        if not os.path.exists(src):
            raise FileNotFoundError("'{0}' does not exist".format(src))

        all_file_list = os.listdir(src)

        # filter the files
        file_list = []
        for f in all_file_list:
            file_path = os.path.join(src, f)
            file_type = os.path.splitext(file_path)[1]
            if os.path.isfile(file_path) and file_type in file_types:
                file_list.append(file_path)

        logger.info(
            "Found {0} files that can be transferred".format(len(file_list))
        )

        for f in file_list:
            if self.stop:
                break
            if self.transfer_file(f, dst):
                files_transferred.append(f)
                ui.update_progress(
                    int(len(files_transferred) / len(file_list) * 100)
                )
                logger.info("Transferred '{0}' to '{1}'".format(f, dst))

        return ExtensionResult(
            rc=0 if len(file_list) - len(files_transferred) == 0 else 1,
            unv_output="The following files were transferred: \n {0}".format(
                json.dumps(files_transferred)
            ),
            message="{0} files found and {1} files transferred".format(
                len(file_list), len(files_transferred)
            ),
        )

    def extension_cancel(self):
        self.stop = True
